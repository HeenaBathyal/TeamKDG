import eventlet
eventlet.monkey_patch()

from flask import Flask, request, jsonify
from flask_sqlalchemy import SQLAlchemy
from flask_jwt_extended import JWTManager, create_access_token, jwt_required, get_jwt_identity
from flask_cors import CORS
from werkzeug.security import generate_password_hash, check_password_hash
from flask_socketio import SocketIO, emit, join_room
import datetime

app = Flask(__name__)
CORS(app)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///sarthi.db'
app.config['JWT_SECRET_KEY'] = 'super-secret-key'
db = SQLAlchemy(app)
jwt = JWTManager(app)
socketio = SocketIO(app, cors_allowed_origins="*")

# --------------------- MODELS ---------------------
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    first_name = db.Column(db.String(100))
    last_name = db.Column(db.String(100))
    email = db.Column(db.String(100), unique=True, nullable=False)
    mobile = db.Column(db.String(15))
    dob = db.Column(db.String(20))
    password_hash = db.Column(db.String(200), nullable=False)
    age = db.Column(db.Integer)
    gender = db.Column(db.String(10))
    city = db.Column(db.String(100))
    diet = db.Column(db.String(20))
    personality = db.Column(db.String(20))
    sleep_habit = db.Column(db.String(20))
    noise_tolerance = db.Column(db.String(20))
    smoke_alcohol = db.Column(db.String(20))
    survey_score = db.Column(db.Integer, default=0)
    final_score = db.Column(db.Integer, default=0)

class Preference(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    preferred_gender = db.Column(db.String(10))
    max_rent = db.Column(db.Integer)
    location = db.Column(db.String(100))
    city = db.Column(db.String(100))

class Recommendation(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer)  # who is getting the recommendation
    recommended_user_id = db.Column(db.Integer)  # who is being recommended
    score = db.Column(db.Integer)



class Message(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    sender_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    receiver_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    content = db.Column(db.String(1000))
    timestamp = db.Column(db.DateTime, default=datetime.datetime.utcnow)

# --------------------- ROUTES ---------------------
@app.route("/")
def home():
    return "Sarthi Backend with Chat is Running!"

@app.route("/register", methods=["POST"])
def register():
    print("✅ Register endpoint hit") 
    data = request.get_json()
    required_fields = ('first_name', 'last_name', 'email', 'mobile', 'dob', 'password')
    if not all(k in data for k in required_fields):
        return jsonify({"message": "Missing registration fields."}), 400

    if User.query.filter_by(email=data['email']).first():
        return jsonify({"message": "User already exists"}), 400

    hashed_pw = generate_password_hash(data['password'])
    user = User(
        first_name=data['first_name'],
        last_name=data['last_name'],
        email=data['email'],
        mobile=data['mobile'],
        dob=data['dob'],
        password_hash=hashed_pw
    )
    db.session.add(user)
    db.session.commit()
    return jsonify({"message": "User registered successfully!"}), 201

@app.route("/login", methods=["POST"])
def login():
    data = request.get_json()
    if not all(k in data for k in ('email', 'password')):
        return jsonify({"message": "Email and password are required."}), 400

    user = User.query.filter_by(email=data['email']).first()
    if not user or not check_password_hash(user.password_hash, data['password']):
        return jsonify({"message": "Invalid credentials"}), 401

    token = create_access_token(identity=str(user.id), expires_delta=datetime.timedelta(days=1))

    return jsonify(
        token=token,
        user={
            "first_name": user.first_name,
            "last_name": user.last_name,
            "email": user.email,
            "mobile": user.mobile,
            "dob": user.dob
        }
    )

@app.route("/submit_traits", methods=["POST"])
@jwt_required()
def submit_traits():
    user_id = get_jwt_identity()
    data = request.get_json()
    user = User.query.get(user_id)

    score = 0
    for trait in ['diet', 'sleep_habit', 'smoke_alcohol', 'noise_tolerance', 'personality']:
        if trait in data:
            setattr(user, trait, data[trait])
            score += 20

    user.survey_score = score
    db.session.commit()
    return jsonify({"message": "Traits submitted", "survey_score": score})

@app.route("/set_preference", methods=["POST"])
@jwt_required()
def set_preference():
    user_id = get_jwt_identity()
    data = request.get_json()

    pref = Preference.query.filter_by(user_id=user_id).first()
    if not pref:
        pref = Preference(user_id=user_id)

    pref.city = data.get('city')
    pref.location = data.get('location')
    pref.max_rent = data.get('max_rent')
    pref.preferred_gender = data.get('preferred_gender')
    db.session.add(pref)
    db.session.commit()

    return jsonify({"message": "Roommate preferences saved!"})

@app.route("/recommendations", methods=["GET"])
@jwt_required()
def recommendations():
    try:
        user_id = get_jwt_identity()
        me = User.query.get(user_id)
        my_pref = Preference.query.filter_by(user_id=user_id).first()

        if not me or not my_pref:
            return jsonify({"message": "Complete profile and preferences first"}), 400

        others = User.query.filter(User.id != user_id).all()
        results = []

        for other in others:
            score = 0
            if me.diet == other.diet:
                score += 20
            if me.personality == other.personality:
                score += 20
            if me.sleep_habit == other.sleep_habit:
                score += 20
            if me.noise_tolerance == other.noise_tolerance:
                score += 20
            if me.smoke_alcohol == other.smoke_alcohol:
                score += 20

            if score > 0:
                results.append({
                    "user_id": me.id,
                    "recommended_user_id": other.id,
                    "recommended_name": f"{other.first_name} {other.last_name}",
                    "message": f"{me.first_name} {me.last_name} is recommended with {other.first_name} {other.last_name}",
                    "score": score
                })

        # Sort by score and take top 2
        top_matches = sorted(results, key=lambda x: x["score"], reverse=True)[:2]

        # Delete previous recommendations
        Recommendation.query.filter_by(user_id=me.id).delete()

        # Save top matches to DB and print to terminal
        for match in top_matches:
            new_rec = Recommendation(
                user_id=match["user_id"],
                recommended_user_id=match["recommended_user_id"],
                score=match["score"]
            )
            db.session.add(new_rec)
            print(f"✅ Saved match: {match['message']} → Score: {match['score']}")

        db.session.commit()

        return jsonify(top_matches)

    except Exception as e:
        print(f"❌ Error in recommendations: {e}")
        return jsonify({"message": "Server error", "error": str(e)}), 500








@app.route("/chat/<int:receiver_id>", methods=["GET"])
@jwt_required()
def get_chat(receiver_id):
    sender_id = get_jwt_identity()
    messages = Message.query.filter(
        ((Message.sender_id == sender_id) & (Message.receiver_id == receiver_id)) |
        ((Message.sender_id == receiver_id) & (Message.receiver_id == sender_id))
    ).order_by(Message.timestamp).all()

    return jsonify([{
        "sender_id": m.sender_id,
        "receiver_id": m.receiver_id,
        "content": m.content,
        "timestamp": m.timestamp.isoformat()
    } for m in messages])

# --------------------- SOCKET.IO REAL-TIME CHAT ---------------------
@socketio.on('join_room')
def on_join(data):
    room = data.get('room')
    join_room(room)
    emit('joined', {'message': f"Joined room {room}"}, room=room)

@socketio.on('send_message')
def handle_message(data):
    sender_id = data.get('sender_id')
    receiver_id = data.get('receiver_id')
    content = data.get('content')

    if not all([sender_id, receiver_id, content]):
        return

    msg = Message(sender_id=sender_id, receiver_id=receiver_id, content=content)
    db.session.add(msg)
    db.session.commit()

    room = f"chat_{min(sender_id, receiver_id)}_{max(sender_id, receiver_id)}"
    emit('receive_message', {
        'sender_id': sender_id,
        'receiver_id': receiver_id,
        'content': content,
        'timestamp': msg.timestamp.isoformat()
    }, room=room)

# --------------------- MAIN ---------------------
if __name__ == "__main__":
    with app.app_context():
        db.create_all()
    socketio.run(app, host='0.0.0.0', port=5000, debug=True)
