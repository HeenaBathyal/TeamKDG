import 'package:flutter/material.dart';
import 'recommend.dart';

class RoommateScreen extends StatelessWidget {
  final String username;

  const RoommateScreen({super.key, required this.username});

  @override
  Widget build(BuildContext context) {
    final TextEditingController cityController = TextEditingController();
    final TextEditingController budgetController = TextEditingController();
    final TextEditingController genderController = TextEditingController();

    return Scaffold(
      backgroundColor: const Color(0xFFFFFBE9),
      appBar: AppBar(
        backgroundColor: const Color(0xFFF47417),
        title: const Text("Find Roommate",
            style: TextStyle(color: Colors.white)),
        centerTitle: true,
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text("Hello, $username!",
                style: const TextStyle(
                    fontSize: 20, fontWeight: FontWeight.bold)),
            const SizedBox(height: 20),
            TextField(
              controller: cityController,
              decoration: const InputDecoration(labelText: "Preferred City"),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: budgetController,
              decoration: const InputDecoration(labelText: "Max Budget (₹)"),
              keyboardType: TextInputType.number,
            ),
            const SizedBox(height: 10),
            TextField(
              controller: genderController,
              decoration: const InputDecoration(labelText: "Gender Preference"),
            ),
            const SizedBox(height: 30),
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => RecommendScreen()),
                );
              },
              style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFFF47417),
                  minimumSize: const Size(double.infinity, 50)),
              child: const Text("Submit"),
            )
          ],
        ),
      ),
    );
  }
}
