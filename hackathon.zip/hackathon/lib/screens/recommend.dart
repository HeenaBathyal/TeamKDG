import 'package:flutter/material.dart';
import 'chat.dart'; // Import the new chat screen

class RecommendScreen extends StatelessWidget {
  const RecommendScreen({super.key});

  @override
  Widget build(BuildContext context) {
    // Sample data for the recommended names.
    // You can replace this with data from your API.
    final List<String> recommendedNames = [
      '@losgirlie',
      '@kewlgal',
      '@babo',
      '@thatgirly01',
      '@johnsmith',
      '@janedoe',
      '@flutterdev',
      '@dartlang',
      '@mobileexpert',
      '@uiuxdesigner',
    ];

    return Scaffold(
      appBar: AppBar(
        title: const Text("Recommended Matches"),
        backgroundColor: const Color(0xFFF47417),
      ),
      body: Container(
        // Add padding to the whole body for a better look
        padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
        child: ListView.builder(
          itemCount: recommendedNames.length,
          itemBuilder: (context, index) {
            final name = recommendedNames[index];
            return InkWell(
              // The onTap function will be called when the user clicks on the name
              onTap: () {
                // Navigate to the ChatScreen and pass the name as an argument
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => ChatScreen(userName: name),
                  ),
                );
              },
              child: Card(
                elevation: 4.0,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16.0),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Text(
                    name,
                    style: const TextStyle(
                      fontSize: 18.0,
                      fontWeight: FontWeight.bold,
                      color: Color(0xFFF47417), // Match the app bar color
                    ),
                  ),
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}
