import 'package:flutter/material.dart';

class ChatScreen extends StatelessWidget {
  // A constructor to receive the name of the user to chat with.
  const ChatScreen({super.key, required this.userName});

  final String userName;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFFF47417),
        title: Text("Chat with $userName"),
        centerTitle: true,
      ),
      body: Column(
        children: [
          // This section will be for the chat messages.
          // It's currently a placeholder.
          Expanded(
            child: Center(
              child: Text(
                'Start your conversation with $userName!',
                style: TextStyle(
                  color: Colors.grey[600],
                  fontStyle: FontStyle.italic,
                ),
              ),
            ),
          ),
          // This section is for the message input and send button.
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8.0),
            decoration: BoxDecoration(
              color: Colors.grey[200],
              border: Border(
                top: BorderSide(color: Colors.grey.shade400),
              ),
            ),
            child: SafeArea(
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      decoration: InputDecoration(
                        hintText: "Type a message...",
                        border: InputBorder.none,
                      ),
                    ),
                  ),
                  IconButton(
                    icon: const Icon(Icons.send),
                    color: const Color(0xFFF47417),
                    onPressed: () {
                      // Logic to send message goes here
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(
                          content: Text('Message sent to $userName'),
                          duration: const Duration(milliseconds: 800),
                        ),
                      );
                    },
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
