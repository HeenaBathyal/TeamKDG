import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:sarthi/screens/splash.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // ✅ Initialize Supabase
  await Supabase.initialize(
    url: 'https://jxlykjlhsrdktdevvfnv.supabase.co',
    anonKey: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imp4bHlramxoc3Jka3RkZXZ2Zm52Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTQwODYyNDIsImV4cCI6MjA2OTY2MjI0Mn0.rmn1YVkhs7zGs3VjcG6sOHrEE9jrV58gSZoh1LU6MCg',
  );

  runApp(const SarthiApp());
}

class SarthiApp extends StatelessWidget {
  const SarthiApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Sarthi App',
      theme: ThemeData(
        scaffoldBackgroundColor: const Color(0xFFFFFAE9),
        appBarTheme: const AppBarTheme(
          backgroundColor: Color(0xFFF47417),
          foregroundColor: Colors.white,
        ),
      ),
      home: const SplashScreen(),
    );
  }
}
