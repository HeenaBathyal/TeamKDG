package com.example.hackathon

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
